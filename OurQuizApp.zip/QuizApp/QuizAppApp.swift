//
//  QuizAppApp.swift
//  QuizApp
//
//  Created by CTSS Students on 15/6/22.
//

import SwiftUI

@main
struct QuizAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
