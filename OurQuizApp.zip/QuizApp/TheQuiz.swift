//
//  TheQuiz.swift
//  QuizApp
//
//  Created by CTSS Students on 15/6/22.
//

import Foundation

struct Quiz {
    
    var question: String
    var option1: String
    var option2: String
    var option3: String
    var option4: String
    var answer: Int
    
    
}
